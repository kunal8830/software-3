#include "stack_library_static.h"

void main(){

    Stack S;

    init(&S);

    S = push(S, 10);
    S = push(S, 3);
    S = push(S, 40);


    printf("top element : %d", peek(&S));

    S = pop(S);
    S = push(S,50);

    while(!isEmpty(&S)) {
        printf("Popping elements: %d\n",peek(&S));
        S = pop(S);
    }
}