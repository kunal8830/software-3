# include "stack_library_dynamic.h"

void main(){
    Stack S;

    init(&S);

    push(&S,10);
    push(&S,20);
    push(&S,30);

    printf("Top elements popped:%d \n", pop(&S));
    printf("Top elements popped:%d \n", pop(&S));
    printf("Top elements popped:%d \n", pop(&S));
    printf("Top elements popped:%d \n", pop(&S));
}