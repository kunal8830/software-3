#include "queue_library_dynamic.h"
#include <stdio.h>
#include <stdlib.h>


void main(){
    Queue Q;

    init(&Q);

    enqueue(&Q, 10);
    enqueue(&Q, 20);
    enqueue(&Q, 30);

    printf("first dequeue %d\n",dequeue(&Q));
    printf("second dequeue %d\n",dequeue(&Q));
    printf("third dequeue %d\n",dequeue(&Q));
    printf("fourth dequeue %d\n",dequeue(&Q));

}